from setuptools import setup

setup(
    name="paquete_clientes",
    version="1.0",
    description="SegundaPre-Entrega",
    author="Werjman Matias",
    author_email="matiasjaw80@gmail.com",
    packages=["paquete_clientes"],
    include_package_data=True,
)